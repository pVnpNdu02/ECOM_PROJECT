package com.example.ecommerce.Controller;

import com.example.ecommerce.Model.Product;
import com.example.ecommerce.Repository.ProductRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PostMapping;

@RestController
@RequestMapping("/products")
@CrossOrigin(origins = "http://localhost:3000")
public class ProductController {

    @Autowired
    private ProductRepo productRepo;

    @PostMapping("/add")
    public ResponseEntity<?> addProduct(@RequestBody Product product) {
        product.setId(null);
        Product saved = productRepo.save(product);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/merchant/{merchant}")
    public List<Product> getByMerchant(@PathVariable String merchant) {
        return productRepo.findByMerchant(merchant);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateProduct(@PathVariable String id, @RequestBody Product updatedProduct) {
        Optional<Product> productOpt = productRepo.findById(id);
        if (productOpt.isPresent()) {
            Product product = productOpt.get();
            product.setName(updatedProduct.getName());
            product.setDescription(updatedProduct.getDescription());
            product.setPrice(updatedProduct.getPrice());
            product.setQuantity(updatedProduct.getQuantity());
            return ResponseEntity.ok(productRepo.save(product));
        }
        return ResponseEntity.notFound().build();
    }
}

