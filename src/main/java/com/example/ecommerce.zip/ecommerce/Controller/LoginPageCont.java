package com.example.ecommerce.Controller;
import com.example.ecommerce.Model.User;
import com.example.ecommerce.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:3000")

public class LoginPageCont {
    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        Optional<User> loggedIn = userService.login(user.getEmail(), user.getPassword());

        if (loggedIn.isPresent()) {
            return ResponseEntity.ok(loggedIn.get());  // Sends back full user object
        } else {
            return ResponseEntity.status(401).body("Invalid credentials");


        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        Optional<User> existing = userService.findByEmail(user.getEmail());
        if (existing.isPresent()) {
            return ResponseEntity.status(400).body("Email already in use");
        }

        User saved = userService.saveUser(user);
        return ResponseEntity.ok(saved);
    }
}
