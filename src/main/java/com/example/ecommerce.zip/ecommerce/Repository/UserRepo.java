//package com.example.ecom.Repository;
//
//
//import com.example.ecom.Model.User;
//
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.stereotype.Repository;
//
//
//import java.util.Optional;
//@Repository
//public interface UserRepo extends MongoRepository<User, String> {
//    Optional<User> findByEmail(String email);
//}
package com.example.ecommerce.Repository;

import com.example.ecommerce.Model.User;

import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface UserRepo extends MongoRepository<User, String> {
    Optional<User> findByEmail(String email);
    Optional<User> findByEmailAndPassword(String email, String password);
}
