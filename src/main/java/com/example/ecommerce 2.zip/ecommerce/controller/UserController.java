package com.example.ecommerce.controller;



import com.example.ecommerce.model.User;
import com.example.ecommerce.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    @Autowired
    private UserRepo userRepo;
    @PutMapping("/merchant/{merchantId}")
    public ResponseEntity<?> updateMerchantByMerchantId(
            @PathVariable String merchantId,
            @RequestBody User updatedUser) {
        Optional<User> userOpt = userRepo.findByMerchantId(merchantId);

        if (userOpt.isPresent()) {
            User existingUser = userOpt.get();
            existingUser.setName(updatedUser.getName());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPhone(updatedUser.getPhone());
            existingUser.setAddress(updatedUser.getAddress());
            existingUser.setPassword(updatedUser.getPassword());
            userRepo.save(existingUser);
            return ResponseEntity.ok(existingUser);
        } else {
            return ResponseEntity.status(404).body("Merchant not found");
        }
    }


    @GetMapping("/merchant-id/{name}")
    public ResponseEntity<String> getMerchantId(@PathVariable String name) {
        User user = userRepo.findByName(name);
        if (user != null) {
            return ResponseEntity.ok(user.getMerchantId());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/id-by-email/{email}")
    public ResponseEntity<String> getIdByEmail(@PathVariable String email) {
        Optional<User> userOpt = userRepo.findByEmail(email);
        if (userOpt.isPresent()) {
            return ResponseEntity.ok(userOpt.get().getId().toString()); // Send `_id` as a string
        } else {
            return ResponseEntity.status(404).body("User not found");
        }
    }
    @GetMapping("/merchant/{merchantId}")
    public ResponseEntity<User> getUserByMerchantId(@PathVariable String merchantId) {
        Optional<User> userOpt = userRepo.findByMerchantId(merchantId);

        if (userOpt.isPresent()) {
            return ResponseEntity.ok(userOpt.get());
        } else {
            return ResponseEntity.status(404).body(null);
        }
    }
}
