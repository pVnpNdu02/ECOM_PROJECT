package com.example.ecommerce.service;

import com.example.ecommerce.model.User;
import com.example.ecommerce.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService{

    @Autowired
    private UserRepo userRepository;

    // Login method to directly compare plain text passwords
    public Optional<User> login(String email, String password) {
        Optional<User> user = userRepository.findByEmail(email);

        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user;  // Password matches, return user
        }
        return Optional.empty();  // Invalid credentials
    }

    // Registration method (store password in plain text)
    public User registerUser(User user) throws Exception {
        // Check if the email already exists
        Optional<User> existingEmail = userRepository.findByEmail(user.getEmail());
        if (existingEmail.isPresent()) {
            throw new Exception("Email already in use.");
        }

        // Check if the merchant ID already exists
        if (userRepository.existsByMerchantId(user.getMerchantId())) {
            throw new Exception("Merchant ID already exists. Please choose a different one.");
        }

        // Save and return the user if both email and merchantId are unique
        return userRepository.save(user);
    }

    // Method to find user by email (for registration and login)
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    public boolean existsByMerchantId(String merchantId) {
        return userRepository.existsByMerchantId(merchantId);
    }
    public User saveUser(User user) {
        return userRepository.save(user);  // Save user using MongoRepository
    }
    public String getMerchantIdByUsername(String username) {
        // Assuming the User entity has a merchantId field and is stored in a database
        User user = userRepository.findByName(username);

        if (user != null) {
            return user.getMerchantId();  // Return the merchantId associated with the user
        } else {
            return null;
        }
    }

    public Optional<User> findByMerchantId(String merchantId) {
        return userRepository.findByMerchantId(merchantId);
    }

}
